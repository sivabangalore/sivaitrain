<?php
$conn = mysql_connect("localhost","kplconst_demo1","pranto007")
                 or die("Could Not Coonect");
    mysql_select_db("kplconst_demo") or die ("No");

?>